import React from "react";
import ReactDOM from "react-dom";

let greeting;
const currentTime = new Date().getHours();
const customFontcolor = {
  color: "",
};

if (currentTime < 12) {
  greeting = "Good Morning";
  customFontcolor.color = { color: "red" };
} else if (currentTime < 18) {
  greeting = "Good Afternoon";
  customFontcolor.color = { color: "green" };
} else {
  greeting = "Good Evening";
  customFontcolor.color = { color: "blue" };
}

ReactDOM.render(
  <h1 style={customFontcolor.color} className="heading">
    {greeting}
  </h1>,
  document.getElementById("root")
);
