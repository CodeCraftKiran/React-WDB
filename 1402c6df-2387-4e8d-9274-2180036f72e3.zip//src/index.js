import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1 className="heading" contentEditable="true">
      My Favourite Foods
    </h1>
    <div>
      <img src="https://sausagemaker.com/wp-content/uploads/Homemade-French-Fries_8.jpg" />
      <img src="https://thewoods.net.in/wp-content/uploads/2021/02/afganimctikka.jpg" />
    </div>
  </div>,
  document.getElementById("root")
);
