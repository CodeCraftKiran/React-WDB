import React from "react";
import ReactDOM from "react-dom";

const fname = "Kiran";
const lname = "princess";

const luckyNum = 10;
ReactDOM.render(
  <>
    <h1>
      Hello I am {fname} {lname}
    </h1>
    {/* <h1>MY lucky number is {luckyNum}</h1> */}
    <h1>MY lucky number is {Math.ceil(Math.random() * 10)}</h1>
  </>,

  document.getElementById("root")
);
// { in this braces expression can be used not statments like if, for, while}
