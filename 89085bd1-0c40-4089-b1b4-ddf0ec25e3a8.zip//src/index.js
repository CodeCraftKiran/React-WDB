var numbers = [3, 56, 2, 48, 5];

//Map -Create a new array by doing something with each item in an array.
// const newArray = numbers.map(function (x) {
//   return x * 2;
// });
// console.log(newArray);

//Filter - Create a new array by keeping the items that return true.
// const newArray = numbers.filter((x) => {
//   return x > 10;
// });
// console.log(newArray);

//Reduce - Accumulate a value by doing something to each item in an array.
// const newArray = numbers.reduce(function (accumulater, cureentNumber) {
//   return accumulater + cureentNumber;
// });
// console.log(newArray);

//Find - find the first item that matches from an array.
// const findNumber = numbers.find(function (x) {
//   return x > 10;
// });
// console.log(findNumber);

//FindIndex - find the index of the first item that matches.
// const findNumber = numbers.findIndex(function (x) {
//   return x > 10;
// });
// console.log(findNumber);

import emojipedia from "./emojipedia";

const newArray = emojipedia.map(function (currentEmoji) {
  return currentEmoji.meaning.substring(0, 100);
});
console.log(newArray);
