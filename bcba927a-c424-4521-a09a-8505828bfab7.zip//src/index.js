import React from "react";
import ReactDOM from "react-dom";
import pi, { DoublePi } from "./math1";

ReactDOM.render(
  <ul>
    <li>{pi}</li>
    <li>{DoublePi()}</li>
    <li>3</li>
  </ul>,
  document.getElementById("root")
);
