pi = 3.14;

function DoublePi() {
  return pi * 2;
}
export default pi;
export { DoublePi };
