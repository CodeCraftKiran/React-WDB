import React from "react";

<ul>
  <li>Bacon</li>
  <li>Jamon</li>
  <li>Noodles</li>
</ul>;
