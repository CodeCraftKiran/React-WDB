import React from "react";
import Avatar from "./avatar";
import Details from "./Details";

function Card(props) {
  return (
    <div className="card">
      <div className="top">
        <h2 className="name">{props.name}</h2>
        <Avatar image={props.img} />
      </div>
      <div className="bottom">
        <Details detail={props.tel} />
        <Details detail={props.email} />
      </div>
    </div>
  );
}

export default Card;
