import React from "react";

function Details(props) {
  return <p className="info">{props.detail}</p>;
}

export default Details;
