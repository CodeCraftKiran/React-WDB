import React from "react";

function Header() {
  return <header>Keeper Part 1</header>;
}

export default Header;
