import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Learning React</h1>
      <p>I am doing Great I am proud of myself.</p>
    </div>
  );
}

export default Note;
