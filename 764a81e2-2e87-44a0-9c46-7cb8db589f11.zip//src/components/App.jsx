import React, { useState } from "react";

function App() {
  setInterval(getTime, 1000);

  let time = new Date().toLocaleTimeString();
  const [initialTime, setTime] = useState(time);

  function getTime() {
    setTime((time = new Date().toLocaleTimeString()));
  }

  return (
    <div className="container">
      <h1>{initialTime}</h1>
      <button onClick={getTime}>Get Time</button>
    </div>
  );
}
// setInterval(App, 1000);

export default App;
