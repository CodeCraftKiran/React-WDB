import React from "react";
import ReactDOM from "react-dom";

// ReactDOM.render(
//   <h1 style={{ color: "pink" }}>Hello World!</h1>,
//   document.getElementById("root")
// );
const customStyle = {
  color: "pink",
  fontSize: "30px",
  border: "1px solid blue",
};

ReactDOM.render(
  <h1 style={customStyle}>Hello World!</h1>,
  document.getElementById("root")
);
